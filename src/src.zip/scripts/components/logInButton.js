export function logInButton() {
    document.getElementById('log-in').addEventListener('click', () => {
        window.location.href = '/home.html';
    });
};
